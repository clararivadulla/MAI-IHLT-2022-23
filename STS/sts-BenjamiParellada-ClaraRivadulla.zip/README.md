# STS - IHLT


All the code is in the directory
- `code_/`

Which contains a function to read the data `data_reader.py`, to extract features `feature_extractor.py`, to build the machine learning frameworks `model.py` as well as plotting utils `utils.py`

sts-BenjamiParellada-ClaraRivadulla.ipnyb acts as a main file for the system with comments of the output.